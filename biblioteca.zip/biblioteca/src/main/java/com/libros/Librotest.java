package com.libros;

import com.restaurante.domain.*;

import java.beans.Transient;
import java.util.Scanner;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class Librotest {
    
    @Test
    public void probarRegistroLibro() {

        Libro libro = new Libro(0, null, null, 0);

        Scanner sc = new Scanner(
            "123\nDune\nFrank Herbert\n50000\n"
        );

         libro.registrarLibro();

        // Comprobamos que los datos sean correctos
        assertEquals(123, libro.getId());
        assertEquals("Dune", libro.getTitulo());
        assertEquals("Frank Herbert", libro.getAutor());
        assertEquals(50000.0, libro.getPrecio());

        sc.close();
    }

    @Test
      public void probarSetterYGetter() {

        Libro libro = new Libro(0, null, null, 0);

        libro.setId(456);
        libro.setTitulo("Fundación");
        libro.setAutor("Isaac Asimov");
        libro.setPrecio(40000);

        assertEquals(456, libro.getId());
        assertEquals("Fundación", libro.getTitulo());
        assertEquals("Isaac Asimov", libro.getAutor());
        assertEquals(40000.0, libro.getPrecio());
    }
}
